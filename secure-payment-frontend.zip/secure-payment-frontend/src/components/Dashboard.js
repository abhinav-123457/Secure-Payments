import React, { useState, useEffect, useRef } from "react";
import { useAuth0 } from "@auth0/auth0-react";
import { ethers } from "ethers";
import { Line, Pie, Bar } from "react-chartjs-2";
import {
  Container,
  Button,
  Card,
  Typography,
  Avatar,
  Box,
  Grid,
  Switch,
  TextField,
  CircularProgress,
  Snackbar,
  Alert,
  CssBaseline,
  ThemeProvider,
  createTheme,
  Slider,
  LinearProgress,
  Chip,
} from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";
import SendIcon from "@mui/icons-material/Send";
import WarningIcon from "@mui/icons-material/Warning";
import SecurityIcon from "@mui/icons-material/Security";
import VpnKeyIcon from "@mui/icons-material/VpnKey";
import ScheduleIcon from "@mui/icons-material/Schedule";
import GroupIcon from "@mui/icons-material/Group";
import { Chart as ChartJS, ArcElement, Tooltip as ChartTooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement } from "chart.js";
import { styled } from "@mui/system";

ChartJS.register(ArcElement, ChartTooltip, Legend, CategoryScale, LinearScale, PointElement, LineElement, BarElement);

// Sleek Neon UI
const NeonButton = styled(Button)(({ theme }) => ({
  background: "linear-gradient(135deg,rgb(0, 15, 230) 0%,rgb(0, 20, 200) 70%)",
  borderRadius: "12px",
  color: "#fff",
  padding: "12px 24px",
  boxShadow: "0 0 15px rgba(0, 61, 230, 0.7)",
  textTransform: "uppercase",
  fontWeight: 700,
  transition: "all 0.3s ease",
  "&:hover": {
    background: "linear-gradient(135deg,rgb(0, 67, 200) 0%,rgb(0, 46, 230) 70%)",
    boxShadow: "0 0 25px rgb(0, 50, 230)",
    transform: "translateY(-2px)",
  },
}));

const NeonCard = styled(Card)(({ theme }) => ({
  background: theme.palette.mode === "dark"
    ? "linear-gradient(145deg, #1a1f2e 0%, #2e364a 100%)"
    : "linear-gradient(145deg, #f0f4f8 0%, #d9e2ec 100%)",
  borderRadius: "16px",
  padding: "24px",
  margin: "16px 0",
  border: "1px solid rgba(0, 230, 118, 0.3)",
  boxShadow: theme.palette.mode === "dark"
    ? "0 8px 24px rgba(0, 0, 0, 0.6), inset 0 0 10px rgba(46, 0, 230, 0.2)"
    : "0 8px 24px rgba(0, 0, 0, 0.1), inset 0 0 10px rgba(0, 200, 83, 0.1)",
  transition: "all 0.3s ease",
  "&:hover": {
    boxShadow: theme.palette.mode === "dark"
      ? "0 12px 32px rgba(0, 0, 0, 0.8), inset 0 0 15px rgba(54, 0, 230, 0.4)"
      : "0 12px 32px rgba(0, 0, 0, 0.2), inset 0 0 15px rgba(0, 3, 200, 0.3)",
  },
}));

const Dashboard = () => {
  const { logout, user } = useAuth0();
  const [walletData, setWalletData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [transactionHistory, setTransactionHistory] = useState([]);
  const [error, setError] = useState(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [recipient, setRecipient] = useState("");
  const [tokenizedRecipient, setTokenizedRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [sending, setSending] = useState(false);
  const [riskScore, setRiskScore] = useState(null);
  const [smartShield, setSmartShield] = useState(false);
  const [multiSigAddress, setMultiSigAddress] = useState("");
  const [networkHealth, setNetworkHealth] = useState("Normal");
  const [gasPriceGwei, setGasPriceGwei] = useState(20);
  const [retryQueue, setRetryQueue] = useState([]);
  const [scheduledTxs, setScheduledTxs] = useState([]);
  const [aiGasPrediction, setAiGasPrediction] = useState("Stable");
  const [aiPriorityScore, setAiPriorityScore] = useState(0);
  const [aiFraudProbability, setAiFraudProbability] = useState(0);
  const [currentNetwork, setCurrentNetwork] = useState(null);
  const [aiSuggestedGas, setAiSuggestedGas] = useState(20);
  const [pendingTxs, setPendingTxs] = useState([]);
  const [batchTxs, setBatchTxs] = useState([{ recipient: "", amount: "" }]);
  const [aiDecisionLog, setAiDecisionLog] = useState([]);
  const [batchResults, setBatchResults] = useState([]);
  const [riskModel, setRiskModel] = useState({
    highAmount: 0.4,
    unknownRecipient: 0.3,
    lowBalance: 0.2,
    rapidTxs: 0.3,
    gasSpike: 0.1,
    learningRate: 0.05,
  });
  const providerRef = useRef(null);

  const theme = createTheme({
    palette: {
      mode: darkMode ? "dark" : "light",
      primary: { main: "#00e676" },
      secondary: { main: "#ff1744" },
      background: { default: darkMode ? "#0d131a" : "#f0f4f8" },
    },
    typography: {
      h4: { fontWeight: 900, letterSpacing: 1.5, fontSize: "2.5rem", fontFamily: "'Montserrat', sans-serif" },
      h5: { fontSize: "1.75rem", fontFamily: "'Montserrat', sans-serif" },
      h6: { fontWeight: 700, fontSize: "1.5rem", fontFamily: "'Montserrat', sans-serif" },
      body1: { fontSize: "1.1rem", fontFamily: "'Roboto', sans-serif" },
    },
  });

  const connectWallet = async () => {
    if (!window.ethereum) {
      setError("MetaMask not detected!");
      setSnackbarOpen(true);
      return;
    }
    try {
      setLoading(true);
      const provider = new ethers.BrowserProvider(window.ethereum);
      providerRef.current = provider;
      const accounts = await provider.send("eth_requestAccounts", []);
      const balanceWei = await provider.getBalance(accounts[0]);
      const network = await provider.getNetwork();
      setWalletData({ address: accounts[0], balance: ethers.formatEther(balanceWei) });
      setCurrentNetwork(network.chainId.toString());
    } catch (error) {
      setError("MetaMask connection failed: " + error.message);
      setSnackbarOpen(true);
    } finally {
      setLoading(false);
    }
  };

  const fetchExternalThreatData = () => {
    return {
      knownThreats: ["0xdeadbeef1234567890abcdef1234567890abcdef"],
      recentSpike: Math.random() > 0.7,
      avgGasTrend: Math.random() * 100,
    };
  };

  const updateRiskModel = (txData, riskOutcome) => {
    const { amountEth, isKnownRecipient, balanceEth, recentTxs, gasPriceGwei } = txData;
    const newModel = { ...riskModel };

    if (riskOutcome > 50) {
      if (amountEth > 5) newModel.highAmount += riskModel.learningRate * 0.1;
      if (!isKnownRecipient) newModel.unknownRecipient += riskModel.learningRate * 0.1;
      if (amountEth > balanceEth * 0.8) newModel.lowBalance += riskModel.learningRate * 0.1;
      if (recentTxs.length > 3) newModel.rapidTxs += riskModel.learningRate * 0.1;
      if (parseFloat(gasPriceGwei) > 500) newModel.gasSpike += riskModel.learningRate * 0.1;
    }

    Object.keys(newModel).forEach(key => newModel[key] = Math.max(0.1, Math.min(0.5, newModel[key])));
    setRiskModel(newModel);
    setAiDecisionLog(prev => [
      ...prev.slice(-4),
      { timestamp: new Date().toLocaleTimeString(), decisions: [`Model updated: ${JSON.stringify(newModel)}`], riskScore: riskOutcome }
    ]);
  };

  const assessTransactionRisk = async (amount, recipient, walletData, transactionHistory) => {
    let riskScore = 0;
    let priorityScore = 0;
    const decisions = [];
    const amountEth = parseFloat(amount) || 0;
    const balanceEth = parseFloat(walletData.balance);
    const recentTxs = transactionHistory.filter(tx => Date.now() / 1000 - parseInt(tx.timeStamp) < 600);
    const externalData = fetchExternalThreatData();

    if (amountEth > 5) {
      riskScore += 50 * riskModel.highAmount;
      decisions.push(`High amount detected (>5 ETH, +${(50 * riskModel.highAmount).toFixed(1)} risk)`);
    }
    const isKnownRecipient = transactionHistory.some(tx => tx.to.toLowerCase() === recipient.toLowerCase());
    if (!isKnownRecipient) {
      riskScore += 30 * riskModel.unknownRecipient;
      decisions.push(`Unknown recipient (+${(30 * riskModel.unknownRecipient).toFixed(1)} risk)`);
    } else {
      priorityScore += 20;
    }
    if (amountEth > balanceEth * 0.8) {
      riskScore += 20 * riskModel.lowBalance;
      decisions.push(`Low balance relative to amount (+${(20 * riskModel.lowBalance).toFixed(1)} risk)`);
    }
    if (recentTxs.length > 3) {
      riskScore += 40 * riskModel.rapidTxs;
      decisions.push(`Rapid transactions detected (>3 in 10m, +${(40 * riskModel.rapidTxs).toFixed(1)} risk)`);
    }
    if (recentTxs.length > 0) priorityScore += recentTxs.length * 10;

    const feeData = await providerRef.current.getFeeData();
    const gasPriceGwei = ethers.formatUnits(feeData.gasPrice || feeData.maxFeePerGas || 0, "gwei");
    if (parseFloat(gasPriceGwei) > 500) {
      riskScore += 20 * riskModel.gasSpike;
      decisions.push(`Gas price spike (>500 Gwei, +${(20 * riskModel.gasSpike).toFixed(1)} risk)`);
    }

    if (smartShield) {
      riskScore += recentTxs.length * 10;
      decisions.push("Smart Shield enhanced scrutiny (+10 risk)");
    }
    if (externalData.knownThreats.includes(recipient.toLowerCase())) {
      riskScore += 100;
      decisions.push("Recipient matches external threat database (+100 risk)");
    }
    if (externalData.recentSpike) {
      riskScore += 20;
      decisions.push("Recent threat spike detected (+20 risk)");
    }

    const totalRecentValue = recentTxs.reduce((sum, tx) => sum + parseFloat(ethers.formatEther(tx.value)), 0);
    if (totalRecentValue > 10) {
      riskScore += 50;
      decisions.push("High recent activity (>10 ETH, +50 risk)");
    }

    riskScore = Math.min(riskScore, 100);
    priorityScore = Math.min(priorityScore, 100);
    setAiPriorityScore(priorityScore);
    setAiFraudProbability(riskScore);
    const suggestedGas = Math.max(10, Math.min(50, gasPriceGwei * (1 + priorityScore / 100)));
    setAiSuggestedGas(Math.round(suggestedGas));

    setAiDecisionLog(prev => [
      ...prev.slice(-4),
      { timestamp: new Date().toLocaleTimeString(), decisions, riskScore }
    ]);

    updateRiskModel({ amountEth, isKnownRecipient, balanceEth, recentTxs, gasPriceGwei }, riskScore);

    return {
      score: riskScore,
      isHighRisk: riskScore >= (smartShield ? 60 : 50),
      details: { highAmount: amountEth > 5, unknownRecipient: !isKnownRecipient, lowBalance: amountEth > balanceEth * 0.8, rapidTxs: recentTxs.length > 3 }
    };
  };

  const tokenizeRecipient = () => {
    if (ethers.isAddress(recipient)) {
      const token = `TOK_${recipient.slice(0, 6)}...${recipient.slice(-4)}`;
      setTokenizedRecipient(token);
    } else {
      setTokenizedRecipient("");
    }
  };

  const checkNetworkHealth = async () => {
    const feeData = await providerRef.current.getFeeData();
    const gasPriceGwei = parseFloat(ethers.formatUnits(feeData.gasPrice || feeData.maxFeePerGas || 0, "gwei"));
    if (gasPriceGwei > 700) setNetworkHealth("Congested");
    else if (gasPriceGwei > 300) setNetworkHealth("Busy");
    else setNetworkHealth("Normal");
    return gasPriceGwei;
  };

  const predictGasPrice = (currentGas) => {
    const gasTrends = {
      0: { prediction: "Rising Soon", confidence: 0.7 },
      10: { prediction: "Rising Soon", confidence: 0.85 },
      20: { prediction: "Stable", confidence: 0.9 },
      50: { prediction: "Stable", confidence: 0.8 },
      100: { prediction: "Dropping Soon", confidence: 0.75 },
      300: { prediction: "Dropping Soon", confidence: 0.9 },
      700: { prediction: "Volatile", confidence: 0.95 },
    };
    const thresholds = Object.keys(gasTrends).map(Number).sort((a, b) => a - b);
    const closest = thresholds.reduce((prev, curr) => Math.abs(curr - currentGas) < Math.abs(prev - currentGas) ? curr : prev);
    const { prediction, confidence } = gasTrends[closest];
    setAiGasPrediction(`${prediction} (${(confidence * 100).toFixed(0)}% confidence)`);
    return prediction;
  };

  const checkRiskOnInput = async () => {
    if (!walletData || !recipient || !amount || !ethers.isAddress(recipient) || isNaN(amount) || amount <= 0) {
      setRiskScore(null);
      setAiPriorityScore(0);
      setAiFraudProbability(0);
      setAiSuggestedGas(20);
      return;
    }
    const risk = await assessTransactionRisk(amount, recipient, walletData, transactionHistory);
    setRiskScore(risk);
  };

  const sendTransaction = async (queuedTx = null, isBatch = false) => {
    const txRecipient = queuedTx?.recipient || recipient;
    const txAmount = queuedTx?.amount || amount;

    if (!walletData || !txRecipient || !txAmount || !ethers.isAddress(txRecipient) || isNaN(txAmount) || txAmount <= 0) {
      setError("Invalid input!");
      setSnackbarOpen(true);
      return null;
    }

    const risk = await assessTransactionRisk(txAmount, txRecipient, walletData, transactionHistory);

    if (risk.isHighRisk && multiSigAddress === "" && !queuedTx) {
      setError("High-risk tx requires multi-sig approval!");
      setSnackbarOpen(true);
      return null;
    }

    if (networkHealth === "Congested" && !queuedTx) {
      setError("Network congested—queued for retry!");
      setRetryQueue([...retryQueue, { recipient: txRecipient, amount: txAmount }]);
      setSnackbarOpen(true);
      return null;
    }

    try {
      setSending(true);
      const signer = await providerRef.current.getSigner();
      const gasPrice = ethers.parseUnits(aiSuggestedGas.toString(), "gwei");

      const tx = await signer.sendTransaction({
        to: txRecipient,
        value: ethers.parseEther(txAmount),
        gasPrice,
      });

      const pending = { hash: tx.hash, status: "Pending", confirmations: 0, timestamp: Date.now(), blockNumber: null };
      setPendingTxs([...pendingTxs, pending]);

      if (risk.isHighRisk) {
        setError("Awaiting multi-sig approval...");
        setSnackbarOpen(true);
        await new Promise(resolve => setTimeout(resolve, 2000));
        setError("Fraud alert broadcast to network!");
        setSnackbarOpen(true);
      }

      const receipt = await tx.wait();
      setPendingTxs(pendingTxs.map(p => p.hash === tx.hash ? { ...p, status: "Confirmed", confirmations: receipt.confirmations, blockNumber: receipt.blockNumber } : p));
      setError("Transaction successful!");
      setSnackbarOpen(true);
      fetchTransactionHistory(walletData.address);

      if (isBatch) {
        setBatchResults(prev => [...prev, { recipient: txRecipient, amount: txAmount, status: "Success", hash: tx.hash }]);
      }

      if (queuedTx) {
        setRetryQueue(retryQueue.filter(q => q !== queuedTx));
      }
      return tx.hash;
    } catch (error) {
      if (!queuedTx) {
        setRetryQueue([...retryQueue, { recipient: txRecipient, amount: txAmount }]);
        setError("Tx failed—queued for retry: " + error.message);
      } else {
        setError("Retry failed: " + error.message);
      }
      if (isBatch) {
        setBatchResults(prev => [...prev, { recipient: txRecipient, amount: txAmount, status: "Failed", error: error.message }]);
      }
      setSnackbarOpen(true);
      return null;
    } finally {
      setSending(false);
      if (!queuedTx && !isBatch) {
        setRecipient("");
        setAmount("");
        setTokenizedRecipient("");
        setMultiSigAddress("");
        setRiskScore(null);
        setAiPriorityScore(0);
        setAiFraudProbability(0);
        setAiSuggestedGas(20);
      }
    }
  };

  const scheduleTransaction = () => {
    if (!recipient || !amount || !ethers.isAddress(recipient) || isNaN(amount) || amount <= 0) {
      setError("Invalid input for scheduling!");
      setSnackbarOpen(true);
      return;
    }
    const scheduled = { recipient, amount, time: Date.now() + 10000 };
    if (aiFraudProbability > 50) {
      setError("AI advises scheduling due to high fraud risk!");
      setSnackbarOpen(true);
    }
    setScheduledTxs([...scheduledTxs, scheduled]);
    setError(`Payment scheduled for ${new Date(scheduled.time).toLocaleTimeString()}!`);
    setSnackbarOpen(true);
    setRecipient("");
    setAmount("");
    setTokenizedRecipient("");
  };

  const executeBatchTransactions = async () => {
    if (batchTxs.some(tx => !tx.recipient || !tx.amount || !ethers.isAddress(tx.recipient) || isNaN(tx.amount) || tx.amount <= 0)) {
      setError("Invalid batch inputs!");
      setSnackbarOpen(true);
      return;
    }
    setSending(true);
    setBatchResults([]);
    const txHashes = [];
    for (const tx of batchTxs) {
      const hash = await sendTransaction(tx, true);
      if (hash) txHashes.push(hash);
    }
    if (txHashes.length === batchTxs.length) {
      setError(`Batch of ${txHashes.length} transactions executed!`);
      setBatchTxs([{ recipient: "", amount: "" }]);
    } else {
      setError(`Batch partially executed: ${txHashes.length}/${batchTxs.length} succeeded`);
    }
    setSnackbarOpen(true);
    setSending(false);
  };

  const fetchTransactionHistory = async (address) => {
    if (!address) return;

    const API_KEY = "QZZZZJNM8AC2AGSJAPKFQN66JQC8DKZ4S4"; // Replace with your real key
    let apiUrl = `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=asc&apikey=${API_KEY}`;

    switch (currentNetwork) {
      case "11155111":
        apiUrl = `https://api-sepolia.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=asc&apikey=${API_KEY}`;
        break;
      case "1":
        apiUrl = `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&sort=asc&apikey=${API_KEY}`;
        break;
      default:
        setError("Unsupported network for tx history!");
        setSnackbarOpen(true);
        return;
    }

    try {
      const response = await fetch(apiUrl);
      const data = await response.json();
      console.log("Etherscan Response:", data);
      if (data.status === "1" && Array.isArray(data.result)) {
        setTransactionHistory(data.result);
      } else {
        setError(`No transactions: ${data.message}`);
        setSnackbarOpen(true);
        setTransactionHistory([
          { hash: "0xmock1", to: "0x1234567890abcdef1234567890abcdef12345678", value: ethers.parseEther("0.1"), timeStamp: Math.floor(Date.now() / 1000) - 300 },
          { hash: "0xmock2", to: "0xabcdef1234567890abcdef1234567890abcdef12", value: ethers.parseEther("0.2"), timeStamp: Math.floor(Date.now() / 1000) - 100 },
        ]);
      }
    } catch (error) {
      setError("Failed to fetch history: " + error.message);
      setSnackbarOpen(true);
      setTransactionHistory([
        { hash: "0xmock3", to: "0x1234567890abcdef1234567890abcdef12345678", value: ethers.parseEther("0.3"), timeStamp: Math.floor(Date.now() / 1000) - 200 },
      ]);
    }
  };

  useEffect(() => {
    if (!window.ethereum) return;

    const handleChainChanged = async (chainId) => {
      setCurrentNetwork(chainId);
      const gas = await checkNetworkHealth();
      setGasPriceGwei(parseFloat(gas));
      predictGasPrice(parseFloat(gas));
      if (walletData) {
        const balanceWei = await providerRef.current.getBalance(walletData.address);
        setWalletData({ ...walletData, balance: ethers.formatEther(balanceWei) });
        fetchTransactionHistory(walletData.address);
      }
    };

    window.ethereum.on("chainChanged", handleChainChanged);
    return () => window.ethereum.removeListener("chainChanged", handleChainChanged);
  }, [walletData]);

  useEffect(() => {
    if (walletData?.address) {
      fetchTransactionHistory(walletData.address);
      checkNetworkHealth().then(gas => {
        setGasPriceGwei(parseFloat(gas));
        predictGasPrice(parseFloat(gas));
      });
    }
  }, [walletData, currentNetwork]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (scheduledTxs.length > 0) {
        const now = Date.now();
        const toSend = scheduledTxs.filter(tx => now >= tx.time);
        toSend.forEach(tx => sendTransaction(tx));
        setScheduledTxs(scheduledTxs.filter(tx => now < tx.time));
      }
      if (retryQueue.length > 0 && networkHealth !== "Congested") {
        retryQueue.forEach(tx => sendTransaction(tx));
      }
      const recentValue = transactionHistory
        .filter(tx => Date.now() / 1000 - parseInt(tx.timeStamp) < 600)
        .reduce((sum, tx) => sum + parseFloat(ethers.formatEther(tx.value)), 0);
      if (recentValue > 10) {
        setError("AI Alert: Unusual activity detected (>10 ETH in 10 mins)!");
        setSnackbarOpen(true);
      }
      if (pendingTxs.length > 0 && providerRef.current) {
        providerRef.current.getBlockNumber().then(blockNumber => {
          setPendingTxs(pendingTxs.map(tx => ({
            ...tx,
            confirmations: tx.status === "Pending" && tx.blockNumber ? Math.max(0, blockNumber - tx.blockNumber) : tx.confirmations,
            status: tx.status === "Pending" && blockNumber >= (tx.blockNumber || 0) + 1 ? "Confirmed" : tx.status,
          })));
        }).catch(err => console.log("Block number fetch failed:", err));
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [scheduledTxs, retryQueue, transactionHistory, networkHealth, pendingTxs]);

  useEffect(() => {
    if (walletData) checkRiskOnInput();
  }, [recipient, amount, smartShield]);

  const addBatchTx = () => setBatchTxs([...batchTxs, { recipient: "", amount: "" }]);
  const updateBatchTx = (index, field, value) => {
    const newBatchTxs = [...batchTxs];
    newBatchTxs[index][field] = value;
    setBatchTxs(newBatchTxs);
  };

  const isContractVerified = (address) => {
    const verifiedContracts = ["0xabcdef1234567890abcdef1234567890abcdef12"];
    return verifiedContracts.includes(address.toLowerCase());
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box sx={{ minHeight: "100vh", background: darkMode ? "linear-gradient(to bottom, #0d131a, #1a1f2e)" : "linear-gradient(to bottom, #f0f4f8, #d9e2ec)", py: 4 }}>
        <Container maxWidth="lg" sx={{ textAlign: "center" }}>
          <Typography variant="h4" sx={{ mb: 4, color: darkMode ? "#00e676" : "#00c853", textShadow: "0 2px 8px rgba(0, 230, 118, 0.5)" }}>
            Secure Payments
          </Typography>
          <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 4, maxWidth: "1000px", mx: "auto" }}>
            <Switch checked={darkMode} onChange={() => setDarkMode(!darkMode)} sx={{ "& .MuiSwitch-thumb": { boxShadow: "0 0 5px #00e676" } }} />
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <SecurityIcon sx={{ color: "#00e676", fontSize: 28 }} />
              <Typography sx={{ fontWeight: 600, color: darkMode ? "#fff" : "#333" }}>Smart Shield</Typography>
              <Switch checked={smartShield} onChange={() => setSmartShield(!smartShield)} sx={{ "& .MuiSwitch-thumb": { boxShadow: "0 0 5px #00e676" } }} />
            </Box>
          </Box>
          <Avatar src={user?.picture} alt={user?.name} sx={{ width: 100, height: 100, mx: "auto", border: "3px solid #00e676", boxShadow: "0 0 15px rgba(0, 230, 118, 0.5)" }} />
          <Typography variant="h5" sx={{ mt: 2, color: darkMode ? "#fff" : "#333" }}>Welcome, {user?.name || "User"}</Typography>
          <Box sx={{ display: "flex", justifyContent: "center", gap: 3, mt: 2 }}>
            <Typography variant="body1" sx={{ color: "#00e676" }}>
              Network: {currentNetwork ? `Chain ID ${currentNetwork}` : "Not Connected"}
            </Typography>
            <Typography variant="body1" sx={{ color: networkHealth === "Congested" ? "#ff1744" : "#00e676" }}>
              Health: {networkHealth}
            </Typography>
            <Typography variant="body1" sx={{ color: "#00e676" }}>
              AI Gas: {aiGasPrediction}
            </Typography>
          </Box>
          {loading ? (
            <CircularProgress sx={{ color: "#00e676", mt: 4 }} size={50} />
          ) : walletData ? (
            <>
              <Grid container spacing={3} sx={{ mt: 4 }}>
                <Grid item xs={12} sm={6}>
                  <NeonCard>
                    <AccountBalanceWalletIcon sx={{ color: "#00e676", fontSize: 50 }} />
                    <Typography variant="body1" sx={{ mt: 2, color: darkMode ? "#b0bec5" : "#546e7a" }}>
                      Address: {walletData.address.slice(0, 6)}...{walletData.address.slice(-4)}
                    </Typography>
                  </NeonCard>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <NeonCard>
                    <MonetizationOnIcon sx={{ color: "#00e676", fontSize: 50 }} />
                    <Typography variant="body1" sx={{ mt: 2, color: darkMode ? "#b0bec5" : "#546e7a" }}>
                      Balance: {walletData.balance} ETH
                    </Typography>
                  </NeonCard>
                </Grid>
              </Grid>

              <Grid container spacing={3} sx={{ mt: 4 }}>
                <Grid item xs={12} md={6}>
                  <NeonCard sx={{ p: 2 }}>
                    <Pie data={{
                      labels: ["Balance", "Spent"],
                      datasets: [{ data: [walletData.balance, 5], backgroundColor: ["#00e676", "#ff1744"], borderColor: "#fff", borderWidth: 1 }],
                    }} options={{ maintainAspectRatio: false }} height={250} />
                  </NeonCard>
                </Grid>
                <Grid item xs={12} md={6}>
                  <NeonCard sx={{ p: 2 }}>
                    <Line data={{
                      labels: transactionHistory.slice(-5).map((_, i) => `Tx ${i + 1}`),
                      datasets: [{
                        label: "Tx Values (ETH)",
                        data: transactionHistory.slice(-5).map(tx => ethers.formatEther(tx.value)),
                        borderColor: "#00e676",
                        backgroundColor: "rgba(0, 230, 118, 0.3)",
                        tension: 0.4,
                        pointBackgroundColor: "#fff",
                        pointBorderColor: "#00e676",
                      }],
                    }} options={{ maintainAspectRatio: false }} height={250} />
                  </NeonCard>
                </Grid>
              </Grid>

              <Box sx={{ mt: 6 }}>
                <Typography variant="h6" sx={{ color: darkMode ? "#fff" : "#00c853", mb: 3 }}>
                  Send ETH - Secure & Fast
                </Typography>
                <NeonCard>
                  <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
                    <TextField
                      fullWidth
                      label="Recipient Address"
                      value={tokenizedRecipient || recipient}
                      onChange={(e) => { setRecipient(e.target.value); setTokenizedRecipient(""); }}
                      sx={{
                        bgcolor: darkMode ? "rgba(255, 255, 255, 0.05)" : "rgba(255, 255, 255, 0.9)",
                        borderRadius: 1,
                        "& .MuiInputLabel-root": { color: darkMode ? "#b0bec5" : "#546e7a" },
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": { borderColor: "#00e676" },
                          "&:hover fieldset": { borderColor: "#00c853" },
                          "&.Mui-focused fieldset": { borderColor: "#00e676", boxShadow: "0 0 10px rgba(0, 230, 118, 0.5)" },
                        },
                      }}
                      variant="outlined"
                    />
                    <Button
                      variant="outlined"
                      startIcon={<VpnKeyIcon />}
                      onClick={tokenizeRecipient}
                      sx={{ borderColor: "#00e676", color: "#00e676", "&:hover": { borderColor: "#00c853", color: "#00c853" } }}
                      disabled={!recipient || tokenizedRecipient}
                    >
                      Tokenize
                    </Button>
                  </Box>
                  <TextField
                    fullWidth
                    label="Amount (ETH)"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    sx={{
                      mt: 2,
                      bgcolor: darkMode ? "rgba(255, 255, 255, 0.05)" : "rgba(255, 255, 255, 0.9)",
                      borderRadius: 1,
                      "& .MuiInputLabel-root": { color: darkMode ? "#b0bec5" : "#546e7a" },
                      "& .MuiOutlinedInput-root": {
                        "& fieldset": { borderColor: "#00e676" },
                        "&:hover fieldset": { borderColor: "#00c853" },
                        "&.Mui-focused fieldset": { borderColor: "#00e676", boxShadow: "0 0 10px rgba(0, 230, 118, 0.5)" },
                      },
                    }}
                    variant="outlined"
                  />
                  {riskScore?.isHighRisk && (
                    <TextField
                      fullWidth
                      label="Multi-Sig Co-Signer Address (Mock)"
                      value={multiSigAddress}
                      onChange={(e) => setMultiSigAddress(e.target.value)}
                      sx={{
                        mt: 2,
                        bgcolor: darkMode ? "rgba(255, 255, 255, 0.05)" : "rgba(255, 255, 255, 0.9)",
                        borderRadius: 1,
                        "& .MuiInputLabel-root": { color: darkMode ? "#b0bec5" : "#546e7a" },
                        "& .MuiOutlinedInput-root": {
                          "& fieldset": { borderColor: "#00e676" },
                          "&:hover fieldset": { borderColor: "#00c853" },
                          "&.Mui-focused fieldset": { borderColor: "#00e676", boxShadow: "0 0 10px rgba(0, 230, 118, 0.5)" },
                        },
                      }}
                      variant="outlined"
                    />
                  )}
                  <Box sx={{ mt: 3 }}>
                    <Typography sx={{ color: darkMode ? "#fff" : "#00c853" }}>
                      Gas Price (Gwei): {gasPriceGwei}
                    </Typography>
                    <Slider
                      value={gasPriceGwei}
                      onChange={(e, newValue) => setGasPriceGwei(newValue)}
                      min={1}
                      max={100}
                      step={1}
                      sx={{ width: "95%", color: "#00e676", "& .MuiSlider-thumb": { boxShadow: "0 0 10px #00e676" } }}
                    />
                    <Typography sx={{ color: "#00e676", mt: 1 }}>
                      AI Suggested Gas: {aiSuggestedGas} Gwei
                    </Typography>
                  </Box>
                  <Box sx={{ mt: 2 }}>
                    <Typography sx={{ color: "#00e676" }}>
                      AI Priority: {aiPriorityScore}%
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={aiPriorityScore}
                      sx={{ mt: 1, bgcolor: "rgba(0, 0, 0, 0.2)", "& .MuiLinearProgress-bar": { background: "#00e676" }, borderRadius: 4, height: 6 }}
                    />
                    <Typography sx={{ color: aiFraudProbability > 50 ? "#ff1744" : "#00e676", mt: 2 }}>
                      AI Fraud Probability: {aiFraudProbability.toFixed(1)}%
                    </Typography>
                    <LinearProgress
                      variant="determinate"
                      value={aiFraudProbability}
                      sx={{ mt: 1, bgcolor: "rgba(0, 0, 0, 0.2)", "& .MuiLinearProgress-bar": { background: aiFraudProbability > 50 ? "#ff1744" : "#00e676" }, borderRadius: 4, height: 6 }}
                    />
                    <Chip
                      label={isContractVerified(recipient) ? "Verified" : "Unverified"}
                      color={isContractVerified(recipient) ? "success" : "warning"}
                      sx={{ mt: 2, bgcolor: isContractVerified(recipient) ? "rgba(0, 230, 118, 0.2)" : "rgba(255, 152, 0, 0.2)", color: "#fff" }}
                    />
                  </Box>
                  <Box sx={{ mt: 3, height: 200 }}>
                    <Bar data={{
                      labels: ["5m ago", "4m ago", "3m ago", "2m ago", "Now"],
                      datasets: [{
                        label: "AI Risk Trend",
                        data: [20, 30, 40, riskScore?.score / 2 || 0, riskScore?.score || 0],
                        backgroundColor: "rgba(0, 230, 118, 0.6)",
                        borderColor: "#00e676",
                        borderWidth: 1,
                        borderRadius: 4,
                      }],
                    }} options={{ scales: { y: { beginAtZero: true, ticks: { color: darkMode ? "#b0bec5" : "#546e7a" } }, x: { ticks: { color: darkMode ? "#b0bec5" : "#546e7a" } } }, maintainAspectRatio: false }} />
                  </Box>
                  <Box sx={{ mt: 3, display: "flex", justifyContent: "center", gap: 3 }}>
                    <NeonButton
                      startIcon={<SendIcon />}
                      onClick={() => sendTransaction()}
                      disabled={sending}
                    >
                      {sending ? <CircularProgress size={24} sx={{ color: "#fff" }} /> : "Send Now"}
                    </NeonButton>
                    <NeonButton
                      startIcon={<ScheduleIcon />}
                      onClick={scheduleTransaction}
                      disabled={sending}
                    >
                      Schedule
                    </NeonButton>
                    <NeonButton
                      startIcon={<GroupIcon />}
                      onClick={executeBatchTransactions}
                      disabled={sending}
                    >
                      Batch Send
                    </NeonButton>
                    {riskScore && (
                      <Typography sx={{ color: riskScore.isHighRisk ? "#ff1744" : "#00e676", alignSelf: "center", fontWeight: 600 }}>
                        Risk: {riskScore.score.toFixed(1)} {riskScore.isHighRisk && <WarningIcon />}
                      </Typography>
                    )}
                  </Box>
                  {pendingTxs.length > 0 && (
                    <Box sx={{ mt: 4 }}>
                      <Typography sx={{ color: darkMode ? "#fff" : "#00c853", fontWeight: 600 }}>Pending Transactions</Typography>
                      {pendingTxs.map((tx, index) => (
                        <NeonCard key={index} sx={{ mt: 2 }}>
                          <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                            Hash: {tx.hash.slice(0, 6)}...{tx.hash.slice(-4)}
                          </Typography>
                          <Typography sx={{ color: tx.status === "Confirmed" ? "#00e676" : "#ff9800" }}>
                            Status: {tx.status}
                          </Typography>
                          <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                            Confirmations: {tx.confirmations}
                          </Typography>
                        </NeonCard>
                      ))}
                    </Box>
                  )}
                  {retryQueue.length > 0 && (
                    <Typography sx={{ mt: 3, color: "#ff9800", fontWeight: 600 }}>
                      Queued Retries: {retryQueue.length}
                    </Typography>
                  )}
                  {scheduledTxs.length > 0 && (
                    <Box sx={{ mt: 4 }}>
                      <Typography sx={{ color: darkMode ? "#fff" : "#00c853", fontWeight: 600 }}>
                        Scheduled Transactions
                      </Typography>
                      {scheduledTxs.map((tx, index) => (
                        <NeonCard key={index} sx={{ mt: 2 }}>
                          <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                            To: {tx.recipient.slice(0, 6)}...{tx.recipient.slice(-4)}
                          </Typography>
                          <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                            Amount: {tx.amount} ETH
                          </Typography>
                          <Typography sx={{ color: "#00e676" }}>
                            Time: {new Date(tx.time).toLocaleTimeString()}
                          </Typography>
                        </NeonCard>
                      ))}
                    </Box>
                  )}
                  <Box sx={{ mt: 4 }}>
                    <Typography sx={{ color: darkMode ? "#fff" : "#00c853", fontWeight: 600 }}>
                      Batch Transactions
                    </Typography>
                    {batchTxs.map((tx, index) => (
                      <Box key={index} sx={{ display: "flex", gap: 2, mt: 2 }}>
                        <TextField
                          label="Recipient"
                          value={tx.recipient}
                          onChange={(e) => updateBatchTx(index, "recipient", e.target.value)}
                          sx={{
                            bgcolor: darkMode ? "rgba(255, 255, 255, 0.05)" : "rgba(255, 255, 255, 0.9)",
                            borderRadius: 1,
                            flex: 1,
                            "& .MuiInputLabel-root": { color: darkMode ? "#b0bec5" : "#546e7a" },
                            "& .MuiOutlinedInput-root": {
                              "& fieldset": { borderColor: "#00e676" },
                              "&:hover fieldset": { borderColor: "#00c853" },
                              "&.Mui-focused fieldset": { borderColor: "#00e676", boxShadow: "0 0 10px rgba(0, 100, 230, 0.5)" },
                            },
                          }}
                          variant="outlined"
                        />
                        <TextField
                          label="Amount (ETH)"
                          value={tx.amount}
                          onChange={(e) => updateBatchTx(index, "amount", e.target.value)}
                          sx={{
                            bgcolor: darkMode ? "rgba(255, 255, 255, 0.05)" : "rgba(255, 255, 255, 0.9)",
                            borderRadius: 1,
                            flex: 1,
                            "& .MuiInputLabel-root": { color: darkMode ? "#b0bec5" : "#546e7a" },
                            "& .MuiOutlinedInput-root": {
                              "& fieldset": { borderColor: "#00e676" },
                              "&:hover fieldset": { borderColor: "#00c853" },
                              "&.Mui-focused fieldset": { borderColor: "#00e676", boxShadow: "0 0 10px rgba(0, 230, 118, 0.5)" },
                            },
                          }}
                          variant="outlined"
                        />
                      </Box>
                    ))}
                    <NeonButton onClick={addBatchTx} sx={{ mt: 2 }}>
                      + Add Another
                    </NeonButton>
                  </Box>
                  {batchResults.length > 0 && (
                    <Box sx={{ mt: 4 }}>
                      <Typography sx={{ color: darkMode ? "#fff" : "#00c853", fontWeight: 600 }}>
                        Batch Results
                      </Typography>
                      {batchResults.map((result, index) => (
                        <NeonCard key={index} sx={{ mt: 2 }}>
                          <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                            To: {result.recipient.slice(0, 6)}...{result.recipient.slice(-4)}
                          </Typography>
                          <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                            Amount: {result.amount} ETH
                          </Typography>
                          <Typography sx={{ color: result.status === "Success" ? "#00e676" : "#ff1744" }}>
                            Status: {result.status} {result.hash ? `(${result.hash.slice(0, 6)}...)` : result.error ? `(${result.error})` : ""}
                          </Typography>
                        </NeonCard>
                      ))}
                    </Box>
                  )}
                  <Box sx={{ mt: 6 }}>
                    <Typography variant="h6" sx={{ color: darkMode ? "#fff" : "#00c853", mb: 3 }}>
                      AI Decision Log
                    </Typography>
                    <NeonCard>
                      {aiDecisionLog.length > 0 ? (
                        <Box sx={{ maxHeight: 300, overflowY: "auto" }}>
                          {aiDecisionLog.map((entry, index) => (
                            <Box key={index} sx={{ p: 2, mb: 1, borderBottom: "1px solid rgba(0, 104, 230, 0.2)" }}>
                              <Typography sx={{ color: "#00e676" }}>{entry.timestamp}</Typography>
                              {entry.decisions.map((decision, i) => (
                                <Typography key={i} sx={{ color: darkMode ? "#fff" : "#333" }}>
                                  - {decision}
                                </Typography>
                              ))}
                              <Typography sx={{ color: entry.riskScore > 50 ? "#ff1744" : "#00e676" }}>
                                Risk Score: {entry.riskScore.toFixed(1)}
                              </Typography>
                            </Box>
                          ))}
                        </Box>
                      ) : (
                        <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>No AI decisions yet.</Typography>
                      )}
                    </NeonCard>
                  </Box>
                  <Box sx={{ mt: 6 }}>
                    <Typography variant="h6" sx={{ color: darkMode ? "#fff" : "#00c853", mb: 3 }}>
                      Transaction History
                    </Typography>
                    <NeonCard>
                      {transactionHistory.length > 0 ? (
                        <Box sx={{ maxHeight: 300, overflowY: "auto" }}>
                          {transactionHistory.slice(-5).map((tx) => (
                            <Box key={tx.hash} sx={{ p: 2, mb: 1, borderBottom: "1px solid rgba(0, 230, 118, 0.2)" }}>
                              <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                                To: {tx.to.slice(0, 6)}...{tx.to.slice(-4)}
                              </Typography>
                              <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>
                                Amount: {ethers.formatEther(tx.value)} ETH
                              </Typography>
                              <Typography sx={{ color: "#00e676" }}>
                                Time: {new Date(tx.timeStamp * 1000).toLocaleTimeString()}
                              </Typography>
                            </Box>
                          ))}
                        </Box>
                      ) : (
                        <Typography sx={{ color: darkMode ? "#b0bec5" : "#546e7a" }}>No transactions found yet.</Typography>
                      )}
                    </NeonCard>
                  </Box>
                </NeonCard>
              </Box>
            </>
          ) : (
            <NeonButton
              startIcon={<AccountBalanceWalletIcon />}
              onClick={connectWallet}
              sx={{ mt: 6 }}
            >
              Connect MetaMask
            </NeonButton>
          )}

          <NeonButton
            variant="contained"
            color="error"
            sx={{ mt: 6, background: "linear-gradient(135deg, #ff1744 0%, #d81b60 100%)", "&:hover": { background: "linear-gradient(135deg, #d81b60 0%, #ff1744 100%)" } }}
            startIcon={<LogoutIcon />}
            onClick={() => logout()}
          >
            Logout
          </NeonButton>
          <Snackbar open={snackbarOpen} autoHideDuration={6000} onClose={() => setSnackbarOpen(false)}>
            <Alert severity={error?.includes("success") ? "success" : "error"} sx={{ boxShadow: "0 2px 10px rgba(0,0,0,0.2)", bgcolor: darkMode ? "rgba(0, 230, 118, 0.2)" : "rgba(255, 23, 68, 0.2)", color: "#fff" }}>
              {error}
            </Alert>
          </Snackbar>
        </Container>
      </Box>
    </ThemeProvider>
  );
};

export default Dashboard;