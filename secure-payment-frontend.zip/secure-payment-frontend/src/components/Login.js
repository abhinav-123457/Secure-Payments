import React from "react";
import { useAuth0 } from "@auth0/auth0-react";
import {
  Container,
  Typography,
  Button,
  Box,
  CssBaseline,
  ThemeProvider,
  createTheme,
} from "@mui/material";
import LockIcon from "@mui/icons-material/Lock";
import { styled } from "@mui/system";

const NeonButton = styled(Button)(({ theme }) => ({
  background: "linear-gradient(135deg, #E0E0E0 20%, #B0B0B0 80%)", // Bright silver to muted silver
  borderRadius: "10px",
  color: "#0F1419",
  padding: "18px 60px",
  fontSize: "1.4rem",
  fontWeight: 900,
  letterSpacing: 3,
  textTransform: "uppercase",
  boxShadow: "0 0 20px rgba(224, 224, 224, 0.7), 0 0 10px rgba(176, 176, 176, 0.5)",
  transition: "all 0.4s ease",
  position: "relative",
  overflow: "hidden",
  border: "2px solid #00CED1", // Neon cyan accent
  "&:hover": {
    background: "linear-gradient(135deg, #B0B0B0 20%, #E0E0E0 80%)",
    transform: "scale(1.1)",
    boxShadow: "0 0 40px rgba(224, 224, 224, 0.9), 0 0 20px rgba(0, 206, 209, 0.7)",
    borderColor: "#00CED1",
  },
  "&:before": {
    content: '""',
    position: "absolute",
    top: "-50%",
    left: "-50%",
    width: "200%",
    height: "200%",
    background: "radial-gradient(circle, rgba(0, 206, 209, 0.4) 0%, transparent 60%)",
    opacity: 0,
    transition: "opacity 0.4s ease",
  },
  "&:hover:before": {
    opacity: 1,
  },
}));

const Login = () => {
  const { loginWithRedirect } = useAuth0();

  const theme = createTheme({
    palette: {
      mode: "dark",
      primary: { main: "#E0E0E0" }, // Bright silver
      background: { default: "#0F1419" }, // Rich black
    },
    typography: {
      h1: {
        fontFamily: "Orbitron, sans-serif",
        fontWeight: 900,
        fontSize: "3.5rem",
        letterSpacing: 3,
      },
      h6: {
        fontFamily: "Roboto Mono, monospace",
        fontWeight: 600,
        fontSize: "1.3rem",
        color: "#00CED1", // Neon cyan for tagline
      },
      body1: {
        fontFamily: "Roboto Mono, monospace",
        fontSize: "1.1rem",
        color: "#B0B0B0", // Muted silver
      },
    },
  });

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container
        maxWidth="sm"
        sx={{
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          background: "radial-gradient(circle at center, #1E2529 0%, #0F1419 100%)", // Deep black gradient
          borderRadius: "25px",
          p: 5,
          boxShadow: "0 0 80px rgba(224, 224, 224, 0.1), inset 0 0 20px rgba(0, 206, 209, 0.2)",
          position: "relative",
          overflow: "hidden",
          "&:before": {
            content: '""',
            position: "absolute",
            top: "-50%",
            left: "-50%",
            width: "200%",
            height: "200%",
            background: "linear-gradient(45deg, rgba(0, 206, 209, 0.1), transparent)",
            animation: "scan 3s infinite linear",
            transform: "rotate(30deg)",
          },
        }}
      >
        <Box sx={{ textAlign: "center", zIndex: 1 }}>
          <LockIcon
            sx={{
              fontSize: 80,
              color: "#E0E0E0",
              mb: 3,
              filter: "drop-shadow(0 0 15px rgba(224, 224, 224, 0.8))",
              animation: "float 2.5s ease-in-out infinite",
            }}
          />
          <Typography
            variant="h1"
            sx={{
              color: "#E0E0E0",
              textShadow: "0 0 20px rgba(224, 224, 224, 0.7), 0 0 5px rgba(0, 206, 209, 0.5)",
              mb: 1,
            }}
          >
            Secure Payments
          </Typography>
          <Typography
            variant="h6"
            sx={{
              textShadow: "0 0 10px rgba(0, 206, 209, 0.6)",
              mb: 2,
            }}
          >
            AI x Blockchain Fortress
          </Typography>
          <Typography variant="body1" sx={{ mb: 6 }}>
            Unlock the ultimate in crypto security
          </Typography>
          <NeonButton
            startIcon={<LockIcon />}
            onClick={() => loginWithRedirect()}
          >
            Enter Vault
          </NeonButton>
        </Box>

        {/* Inline CSS for animations */}
        <style jsx global>{`
          @keyframes float {
            0%, 100% {
              transform: translateY(0);
            }
            50% {
              transform: translateY(-15px);
            }
          }
          @keyframes scan {
            0% {
              transform: translateY(-100%) rotate(30deg);
            }
            100% {
              transform: translateY(100%) rotate(30deg);
            }
          }
        `}</style>
      </Container>
    </ThemeProvider>
  );
};

export default Login;